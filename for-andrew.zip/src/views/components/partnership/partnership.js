import './partnership.scss'
import './_imports/import'
  
