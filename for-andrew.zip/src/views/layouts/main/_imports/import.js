import '../../../components/header/header'
import '../../../components/footer/footer'
